# User Credentials

Here are the details for the newly created users.

**Default Password for all users:** `password123`

---

### 1. Super Admin
- **Username:** `superadmin`
- **Email:** `superadmin@example.com`
- **Role:** `super_admin`

---

### 2. Company Admin
- **Username:** `companyadmin`
- **Email:** `companyadmin@example.com`
- **Role:** `company_admin`

---

### 3. Regular User
- **Username:** `regularuser`
- **Email:** `user@example.com`
- **Role:** `employee`

password123
